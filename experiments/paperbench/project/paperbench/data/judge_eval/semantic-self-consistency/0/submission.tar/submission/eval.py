import argparse
import asyncio
from collections import Counter
import os
import time
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from tqdm import tqdm

from datasets import Dataset
from lm_datasets import load_hf_dataset
from models import load_model_and_tokenizer
from sampling import CPWSampling, GreedySampling, IsolationForestOutlierRemoval, KNNOutlierRemoval, SCSampling, SCWSampling, SVMOutlierRemoval, SamplingMethod


def answer_extraction(x: str) -> str:
    replace_with_whitespace_chars = [".", "(", ")", "  ", "\n"]
    answer_mapping = {"yes": "true", "no": "false"}
    try:
        x = x.lower()
        for char in replace_with_whitespace_chars:
            x = x.replace(char, " ")
        x = x.strip()
        if "the answer is" not in x:
            return ""

        x = x.split("the answer is ")[-1]
        if x in answer_mapping:
            x = answer_mapping[x]
        return x
    except Exception as e:
        print(e)
        return ""


async def evaluate(
    model: str,
    dataset: Dataset,
    sampling_method: SamplingMethod,
    answer_extraction_fn: callable,
    max_new_tokens: int,
    temperature: float,
    verbose: bool = False,
) -> float:
    num_correct = 0
    num_skipped = 0
    for example in dataset:
        X, y = example["X"], example["y"]
        answer = await sampling_method.sample_answer(model, X, answer_extraction_fn, {"max_new_tokens": max_new_tokens, "do_sample": True, "temperature": temperature, "top_k": 50}, verbose=verbose)

        # For the top prob sample we only evaluated outputs which did extract a some solution, since this should be a comparable cot baseline
        if (isinstance(sampling_method, GreedySampling) and answer == "") or (dataset.info.splits["test"].dataset_name == "aqua_rat" and answer == ""):
            num_skipped += 1
            continue

        if answer.lower() == y.lower():
            num_correct += 1
        elif verbose:
            print(f"Expected: {y.lower()}, got: {answer.lower()}")

    return num_correct / (len(dataset) - num_skipped)


def get_featurizer_model_name(dataset_name: str) -> str:
    if dataset_name == "deepmind/aqua_rat":
        return "allenai/scibert_scivocab_uncased"
    elif dataset_name == "ChilleD/StrategyQA":
        return "FacebookAI/roberta-base"
    elif dataset_name == "ChilleD/SVAMP":
        return "allenai/scibert_scivocab_uncased"
    else:
        raise ValueError(f"Featurizer for dataset {dataset_name} not implemented")


async def main(args: argparse.Namespace):
    print(f"Model: {args.model}, Dataset: {args.dataset}, Sampling Method: {args.sampling_method}, Outlier Method: {args.outlier_method}")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    dataset = load_hf_dataset(args.dataset)
    if args.n_samples:
        dataset = dataset.select(range(args.n_samples))

    outlier_method = None
    if args.outlier_method == "knn":
        outlier_method = KNNOutlierRemoval()
    elif args.outlier_method == "iforest":
        outlier_method = IsolationForestOutlierRemoval()
    elif args.outlier_method == "svm":
        outlier_method = SVMOutlierRemoval()
    
    if args.sampling_method == "greedy":
        sampling_method = GreedySampling()
        temperature = 0.0
    elif args.sampling_method == "sc":
        featurizer, featurizer_tokenizer = None, None
        if args.outlier_method:
            featurizer, featurizer_tokenizer = load_model_and_tokenizer(get_featurizer_model_name(args.dataset), device)
        sampling_method = SCSampling(k=args.k, outlier_method=outlier_method, featurizer=featurizer, featurizer_tokenizer=featurizer_tokenizer)
        temperature = 0.8
    elif args.sampling_method == "cpw":
        featurizer, featurizer_tokenizer = load_model_and_tokenizer(get_featurizer_model_name(args.dataset), device)
        sampling_method = CPWSampling(k=args.k, featurizer=featurizer, featurizer_tokenizer=featurizer_tokenizer)
        temperature = 0.8
    elif args.sampling_method == "scw":
        featurizer, featurizer_tokenizer = load_model_and_tokenizer(get_featurizer_model_name(args.dataset), device)
        sampling_method = SCWSampling(k=args.k, featurizer=featurizer, featurizer_tokenizer=featurizer_tokenizer)
        temperature = 0.8

    answer_extraction_fn = answer_extraction
    accuracy = await evaluate(args.model, dataset, sampling_method, answer_extraction_fn, args.max_new_tokens, temperature, verbose=args.verbose)
    
    # Dump results to csv
    if outlier_method is None:
        filename = "table1.csv"
        columns = ["model", "dataset", "sampling_method", "accuracy"]
        new_row = [args.model, args.dataset, args.sampling_method, accuracy]
    else:
        filename = "table2.csv"
        columns = ["model", "dataset", "sampling_method", "outlier_method", "accuracy"]
        new_row = [args.model, args.dataset, args.sampling_method, args.outlier_method, accuracy]
    if not os.path.exists(filename):
        df = pd.DataFrame(columns=columns)
    else:
        df = pd.read_csv(filename)
    df.loc[len(df)] = new_row
    df.to_csv(filename, index=False)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--model",
        type=str,
        help="Model to use for sampling",
    )
    parser.add_argument(
        "--dataset",
        type=str,
        help="Dataset to use for sampling",
    )
    parser.add_argument(
        "--sampling-method",
        type=str,
        help="Sampling method to use",
        choices=["greedy", "sc", "cpw", "scw"],
    )
    parser.add_argument(
        "--max-new-tokens",
        type=int,
        help="Maximum number of new tokens to generate",
    )
    parser.add_argument(
        "--k",
        type=int,
        help="Number of samples to take",
    )
    parser.add_argument(
        "--n-samples",
        type=int,
        help="Number of samples to evaluate on",
    )
    parser.add_argument(
        "--outlier-method",
        type=str,
        help="Outlier method to use",
        choices=["knn", "iforest", "svm"],
    )
    parser.add_argument(
        "--verbose",
        action="store_true",
    )
    args = parser.parse_args()
    asyncio.run(main(args))
