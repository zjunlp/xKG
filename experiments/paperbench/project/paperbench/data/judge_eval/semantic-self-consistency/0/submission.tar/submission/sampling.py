import asyncio
from openai import AsyncOpenAI
from sklearn.ensemble import IsolationForest
from sklearn.svm import OneClassSVM
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch
from torch.nn import functional as F
from collections import Counter
from sklearn.neighbors import NearestNeighbors
import numpy as np
import tenacity
import openai


OPENAI_TIMEOUT_EXCEPTIONS = (
    openai.RateLimitError,
    openai.APIConnectionError,
    openai.APITimeoutError,
    openai.InternalServerError,
)

@tenacity.retry(
    stop=tenacity.stop_after_attempt(10),
    wait=tenacity.wait_random_exponential(min=1, max=30),
    retry=tenacity.retry_if_exception_type(OPENAI_TIMEOUT_EXCEPTIONS),
    reraise=True,
)
async def call_oai_with_backoff(client: AsyncOpenAI, model: str, messages: list[dict], **kwargs) -> dict:
    return await client.chat.completions.create(model=model, messages=messages, **kwargs)


class OutlierRemoval:
    def __call__(self, embeddings: torch.Tensor) -> torch.Tensor:
        raise NotImplementedError("Outlier removal method not implemented")


class KNNOutlierRemoval(OutlierRemoval):
    def __call__(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        Returns array of bools, where True indicates an outlier
        Only include each point if nearest 5 neighours are all same class
        """
        nn = NearestNeighbors(n_neighbors=6, algorithm='ball_tree', metric="minkowski")  # Use n_neighbors=6 to ensure that we have at least 5 neighbours
        nn.fit(embeddings.detach().cpu().numpy())
       
        distances, _ = nn.kneighbors(embeddings.detach().cpu().numpy())
        distances = distances[:, 1:]  # Remove the first neighbour, which is the point itself
        avg_distances = distances.mean(axis=1)
        max_distance = avg_distances.max()
        mask = avg_distances == max_distance
        return mask


class IsolationForestOutlierRemoval(OutlierRemoval):
    def __call__(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        Returns array of bools, where True indicates an outlier
        """
        iforest = IsolationForest(n_estimators=200, contamination="auto", max_samples="auto")
        iforest.fit(embeddings.detach().cpu().numpy())
        mask = iforest.predict(embeddings.detach().cpu().numpy()) == -1
        return mask


class SVMOutlierRemoval(OutlierRemoval):
    def __call__(self, embeddings: torch.Tensor) -> torch.Tensor:
        """
        Returns array of bools, where True indicates an outlier
        """
        svm = OneClassSVM(kernel="linear", nu=0.01)
        svm.fit(embeddings.detach().cpu().numpy())
        mask = svm.predict(embeddings.detach().cpu().numpy()) == -1
        return mask


class SamplingMethod:
    def sample_answer(self, model: str, X: str, answer_extraction_fn: callable, generation_kwargs: dict | None = None) -> str:
        raise NotImplementedError("Sampling method not implemented")

    async def sample_single_answer(
        self,
        model: str,
        X: str,
        answer_extraction_fn: callable,
        generation_kwargs: dict | None = None,
        verbose: bool = False,
    ) -> tuple[torch.Tensor, str, str]:
        messages = [
            {
                "role": "system",
                "content": "Follow the exact formatting as demonstrated in the examples."
            },
            {
                "role": "user",
                "content": X
            }
        ]
        oai_generation_kwargs = {"top_p": 1}
        if "max_new_tokens" in generation_kwargs:
            oai_generation_kwargs["max_tokens"] = generation_kwargs["max_new_tokens"]
        if "temperature" in generation_kwargs:
            oai_generation_kwargs["temperature"] = generation_kwargs["temperature"]
        client = AsyncOpenAI()
        response = await call_oai_with_backoff(client, model, messages, **oai_generation_kwargs)
        generated_text = response.choices[0].message.content
        
        answer = answer_extraction_fn(generated_text)
        if verbose:
            print(f"===\n{X}{generated_text}\nExtracted: {answer}")
        return generated_text, answer


class GreedySampling(SamplingMethod):
    async def sample_answer(
        self,
        *args,
        **kwargs,
    ) -> str:
        _, answer = await self.sample_single_answer(*args, **kwargs)
        return answer


class SCSampling(SamplingMethod):
    def __init__(self, k: int, featurizer: AutoModelForCausalLM | None = None, featurizer_tokenizer: AutoTokenizer | None = None, outlier_method: OutlierRemoval | None = None):
        self.k = k
        self.featurizer = featurizer
        self.featurizer_tokenizer = featurizer_tokenizer
        self.outlier_method = outlier_method

    def _filter_outliers(self, answers: list[str], generated_texts: list[str]) -> list[str]:
        embeddings = torch.tensor([], device=self.featurizer.device)
        for generated_text in generated_texts:
            tokenized_featurizer = self.featurizer_tokenizer(generated_text, return_tensors="pt")
            input_ids_featurizer = tokenized_featurizer.input_ids.to(self.featurizer.device)
            attention_mask_featurizer = tokenized_featurizer.attention_mask.to(self.featurizer.device)

            # Get embedding of generated text
            out = self.featurizer(input_ids_featurizer, attention_mask_featurizer, output_hidden_states=True)
            cls_embedding = out.hidden_states[-1][0, 0, :]
            embeddings = torch.cat([embeddings, cls_embedding.unsqueeze(0)], dim=0)

        mask = self.outlier_method(embeddings)
        return [answers[i] for i in range(len(answers)) if not mask[i]]
    
    async def sample_answer(
        self,
        model: str,
        X: str,
        answer_extraction_fn: callable,
        generation_kwargs: dict | None = None,
        verbose: bool = False,
    ) -> str:
        tasks = [
            self.sample_single_answer(model, X, answer_extraction_fn, generation_kwargs, verbose)
            for _ in range(self.k)
        ]
        results = await asyncio.gather(*tasks)
        generated_texts, answers = zip(*results)
        generated_texts = list(generated_texts)
        answers = list(answers)
        
        if self.outlier_method is not None:
            answers = self._filter_outliers(answers, generated_texts)

        if verbose:
            print(f"===\n{X}\nAnswers: {answers}")
        if len(answers) == 0:
            return ""
        return Counter(answers).most_common(1)[0][0]


class CPWSampling(SamplingMethod):
    def __init__(self, k: int, featurizer: AutoModelForCausalLM, featurizer_tokenizer: AutoTokenizer):
        self.k = k
        self.featurizer = featurizer
        self.featurizer_tokenizer = featurizer_tokenizer

    async def sample_answer(
        self,
        model: str,
        X: str,
        answer_extraction_fn: callable,
        generation_kwargs: dict | None = None,
        verbose: bool = False,
    ) -> str:
        tasks = [
            self.sample_single_answer(model, X, answer_extraction_fn, generation_kwargs, verbose)
            for _ in range(self.k)
        ]
        results = await asyncio.gather(*tasks)
        generated_texts, answers = zip(*results)
        generated_texts = list(generated_texts)
        answers = list(answers)
        
        # Compute embeddings sequentially
        embeddings = torch.tensor([], device=self.featurizer.device)
        for generated_text in generated_texts:
            # Tokenize generated text
            tokenized_featurizer = self.featurizer_tokenizer(generated_text, return_tensors="pt")
            input_ids_featurizer = tokenized_featurizer.input_ids.to(self.featurizer.device)
            attention_mask_featurizer = tokenized_featurizer.attention_mask.to(self.featurizer.device)

            # Get embedding of generated text
            out = self.featurizer(input_ids_featurizer, attention_mask_featurizer, output_hidden_states=True)
            cls_embedding = out.hidden_states[-1][0, 0, :]
            embeddings = torch.cat([embeddings, cls_embedding.unsqueeze(0)], dim=0)

        # Apply CPW
        centroid = embeddings.mean(dim=0)
        distances = torch.norm(embeddings - centroid.unsqueeze(0), dim=1)
        normalized_distances = distances / distances.sum()
        weights = (1 / (normalized_distances + 1e-8)).unsqueeze(1)  # (k, 1)

        largest_weight = 0
        best_answer = ""
        for answer in list(set(answers)):
            mask = torch.tensor([True if i == answer else False for i in answers])
            filtered_weights = weights[mask]
            filtered_sum = filtered_weights.sum()
            if filtered_sum > largest_weight:
                largest_weight = filtered_sum
                best_answer = answer

        if verbose:
            print(f"===\n{X}\nAnswers: {answers}\nBest answer: {best_answer}")
        return best_answer


class SCWSampling(SamplingMethod):
    def __init__(self, k: int, featurizer: AutoModelForCausalLM, featurizer_tokenizer: AutoTokenizer):
        self.k = k
        self.featurizer = featurizer
        self.featurizer_tokenizer = featurizer_tokenizer

    async def sample_answer(
        self,
        model: str,
        X: str,
        answer_extraction_fn: callable,
        generation_kwargs: dict | None = None,
        verbose: bool = False,
    ) -> str:
        tasks = [
            self.sample_single_answer(model, X, answer_extraction_fn, generation_kwargs, verbose)
            for _ in range(self.k)
        ]
        results = await asyncio.gather(*tasks)
        generated_texts, answers = zip(*results)
        generated_texts = list(generated_texts)
        answers = list(answers)

        # Compute embeddings sequentially
        embeddings = torch.tensor([], device=self.featurizer.device)
        for generated_text in generated_texts:
            # Tokenize generated text
            tokenized_featurizer = self.featurizer_tokenizer(generated_text, return_tensors="pt")
            input_ids_featurizer = tokenized_featurizer.input_ids.to(self.featurizer.device)
            attention_mask_featurizer = tokenized_featurizer.attention_mask.to(self.featurizer.device)

            # Get embedding of generated text
            out = self.featurizer(input_ids_featurizer, attention_mask_featurizer, output_hidden_states=True)
            cls_embedding = out.hidden_states[-1][0, 0, :]
            embeddings = torch.cat([embeddings, cls_embedding.unsqueeze(0)], dim=0)

        # Apply SCW
        e1 = embeddings.unsqueeze(0)
        e2 = embeddings.unsqueeze(1)
        similarities = F.cosine_similarity(e1, e2, dim=2) # f((1, k, D), (1, k, D)) -> (k, k, 1)
        similarities_agg = similarities.sum(dim=1) # f(k, k, 1) -> (k, 1)

        largest_weight = 0
        best_answer = ""
        for answer in list(set(answers)):
            mask = torch.tensor([True if i == answer else False for i in answers])
            filtered_similarities = similarities_agg[mask]
            filtered_sum = filtered_similarities.sum()
            if filtered_sum > largest_weight:
                largest_weight = filtered_sum
                best_answer = answer

        if verbose:
            print(f"===\n{X}\nAnswers: {answers}\nBest answer: {best_answer}")
        return best_answer