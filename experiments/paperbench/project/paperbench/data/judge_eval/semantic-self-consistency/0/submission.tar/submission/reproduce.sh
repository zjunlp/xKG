#!/bin/bash
apt-get update && apt-get install -y python3 python3-pip wget

wget https://repo.anaconda.com/miniconda/Miniconda3-latest-Linux-x86_64.sh
chmod 700 Miniconda3-latest-Linux-x86_64.sh
./Miniconda3-latest-Linux-x86_64.sh -b
source ~/miniconda3/etc/profile.d/conda.sh

conda create -n semantic python=3.11 -y
conda run -n semantic pip install -r requirements.txt

# Function to get max tokens based on dataset
get_max_tokens() {
    local dataset=$1
    case $dataset in
        "ChilleD/SVAMP")
            echo "250"
            ;;
        "deepmind/aqua_rat")
            echo "400"
            ;;
        "ChilleD/StrategyQA")
            echo "450"
            ;;
        *)
            echo "400"  # Default fallback
            ;;
    esac
}

# 5.1
for model in gpt-3.5-turbo gpt-4o-mini ; do
    for dataset in deepmind/aqua_rat ChilleD/SVAMP ChilleD/StrategyQA ; do
        max_tokens=$(get_max_tokens $dataset)
        for sampling_method in greedy sc cpw scw; do
            conda run -n semantic python eval.py \
                --model $model \
                --dataset $dataset \
                --sampling-method $sampling_method \
                --max-new-tokens $max_tokens \
                --k 10
        done
    done
done

# 5.2
for model in gpt-3.5-turbo gpt-4o-mini; do
    for dataset in deepmind/aqua_rat ChilleD/SVAMP ChilleD/StrategyQA ; do
        max_tokens=$(get_max_tokens $dataset)
        for outlier_method in knn svm iforest; do
            conda run -n semantic python eval.py \
                --model $model \
                --dataset $dataset \
                --sampling-method sc \
                --outlier-method $outlier_method \
                --max-new-tokens $max_tokens \
                --k 10
        done
    done
done
