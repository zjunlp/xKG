from datasets import load_dataset, Dataset, concatenate_datasets
from constants import AQUA_RAT_FEW_SHOT, SVAMP_FEW_SHOT, STRATEGYQA_FEW_SHOT


def load_hf_dataset(dataset_name: str) -> Dataset:
    """
    Loads a HuggingFace dataset and sets the keys "X" and "y". Appends the few-shot examples, and
    formats the new example to be in the format of the few-shot examples.
    """
    ds = load_dataset(dataset_name)
    if dataset_name == "deepmind/aqua_rat":
        def format_options(x: list[str]) -> str:
            x = ["(" + i[:2].lower() + " " + i[2:] for i in x]
            return "Answer Choices: " + " ".join(x)

        ds = ds["test"].map(lambda x: {"X": AQUA_RAT_FEW_SHOT + "\nQ: " + x['question'] + "\n" + format_options(x['options']) + "\nA:", "y": x["correct"]})
    elif dataset_name == "ChilleD/StrategyQA":
        ds = ds["test"].map(lambda x: {"X": f"{STRATEGYQA_FEW_SHOT}\nQ: {x['question']}\nA:", "y": str(x["answer"])})
    elif dataset_name == "ChilleD/SVAMP":
        ds = concatenate_datasets([ds["train"], ds["test"]])
        ds = ds.map(lambda x: {"X": f"{SVAMP_FEW_SHOT}\nQ: {x['question_concat']}\nA:", "y": x["Answer"]})
    else:
        raise ValueError(f"Dataset {dataset_name} not supported")
    return ds


# Download datasets
if __name__ == "__main__":
    for dataset in [
        "deepmind/aqua_rat",
        "ChilleD/StrategyQA",
        "ChilleD/SVAMP",
    ]:
        ds = load_hf_dataset(dataset)
        print(ds[0]["X"])
        print(ds[0]["y"])
        print(type(ds[0]["y"]), type(ds[0]["X"]))
