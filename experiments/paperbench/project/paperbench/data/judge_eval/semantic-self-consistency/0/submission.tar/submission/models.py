import os
import subprocess
from transformers import AutoModelForCausalLM, AutoTokenizer, AutoModel
import torch


def load_hf_model_and_tokenizer(model_name: str, device: str | None = None) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
    if "roberta" in model_name or "scibert" in model_name:
        model = AutoModel.from_pretrained(model_name)
    else:
        model = AutoModelForCausalLM.from_pretrained(model_name)
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if device:
        model.to(device)
    return model, tokenizer


def load_model_and_tokenizer(model_name: str, device: str | None = None) -> tuple[AutoModelForCausalLM, AutoTokenizer]:
    if "gpt" in model_name:
        return model_name, None
    else:
        return load_hf_model_and_tokenizer(model_name, device)


# Download weights
if __name__ == "__main__":
    subprocess.run(["huggingface-cli", "login", "--token", os.environ["HF_TOKEN"]])
    for model in [
        "FacebookAI/roberta-base",
        "allenai/scibert_scivocab_uncased",
    ]:
        load_hf_model_and_tokenizer(model)
